
import React, { Component } from 'react'

class Error extends Component {
    render() {
        return (
            <section id='content'>
                <h2 className='subheader'>Página no encontrada</h2>
            </section>
        );
    }
}

export default Error;