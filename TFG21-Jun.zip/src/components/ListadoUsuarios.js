import React, { Component } from 'react'

class ListadoUsuarios extends Component{
    render(){
        return(
            <p>Listado de usuarios</p>
        )
    }
}

export default ListadoUsuarios;