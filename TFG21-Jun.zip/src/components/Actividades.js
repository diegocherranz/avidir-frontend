import React, { Component } from 'react'

class Actividades extends Component{
    render(){
        return(
            <p>Listado de actividades</p>
        )
    }
}

export default Actividades;