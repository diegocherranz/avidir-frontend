import React, { Component } from 'react'
import {Container, Nav, Navbar} from 'react-bootstrap'

class Header extends Component {
    render() {
        return (

            <Navbar bg="primary" className='justify-content-center'>
                    <Navbar.Brand href='/'>Logo</Navbar.Brand>
            </Navbar>
        );
    }
}

export default Header;