import React, { Component } from 'react'
import { Navigate } from 'react-router-dom';
import { getUser,getToken } from './AuthService';


const Home = () => {
    if(getToken() && getUser().tipo === 'C'){
        return <Navigate to='/usuarios' replace/>
    }
    else if(getToken() && getUser().tipo === 'U'){
        console.log(JSON.stringify(getUser()));
        return <Navigate to='/actividades' replace/>
    }

    console.log('No entra en else if' + JSON.stringify(getUser()));

    return <Navigate to='/login' replace/>

}



export default Home;