import React, { Component } from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Header from './Header';
import LoginPage from './LoginPage.js';
import Error from './Error';
import Registrarse from './Registrarse';
import { Container } from 'react-bootstrap';
import PrivateRouteC from '../routes/PrivateRouteC';
import PrivateRouteU from '../routes/PrivateRouteU';
import Actividades from './Actividades';
import Home from './Home';
import ListadoUsuarios from './ListadoUsuarios';

class Router extends Component {
    render() {
        return (

            <BrowserRouter>
                <Header></Header>
                <Routes>
                    <Route exact path='/' element={<Home />} />
                    <Route exact path='/login' element={<LoginPage />} />
                    <Route exact path='/registro' element={<Registrarse />} />
                    <Route exact path='/home' element={<Home />} />
                    <Route path='/actividades' element={<PrivateRouteU />}>
                        <Route path='/actividades' element={<Actividades />} />
                    </Route>
                    <Route path='/usuarios' element={<PrivateRouteC />}>
                        <Route path='/usuarios' element={<ListadoUsuarios />} />
                    </Route>
                    {/*<Route exact path='/actividades' component={Actividades}/>*/}
                    <Route path='*' element={<Error />} />
                </Routes>
            </BrowserRouter>
        );
    }
}

export default Router;