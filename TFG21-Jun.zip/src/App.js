import logo from './logo.svg';
import './App.css';
import LoginPage from './components/LoginPage2.js.old';
import Router from './components/Router';

function App() {
  return (
    <div className="App">
      
      
      <Router/>
    </div>
  );
}

export default App;
